import zipfile
import os

os.makedirs("lib", exist_ok=True)
os.makedirs("assets", exist_ok=True)

# 1. pubspec.yaml फ़ाइल
pubspec_content = """name: all_in_one_tool
description: Clean & Premium Material 3 PDF & Image Suite.
publish_to: 'none'
version: 3.0.0+1
environment:
  sdk: '>=3.0.0 <4.0.0'
dependencies:
  flutter:
    sdk: flutter
  image_picker: ^1.0.7
  pdf: ^3.10.8
  image: ^4.1.3
  path_provider: ^2.1.2
  file_picker: ^6.1.1
  share_plus: ^7.2.1
  google_fonts: ^6.1.0
flutter:
  uses-material-design: true
  assets:
    - assets/qr_code.png
"""

# 2. main.dart फ़ाइल (YouTube जैसा क्लीन, फास्ट और प्रोफेशनल डार्क UI)
main_dart_content = """import 'package:flutter/material.dart';
import 'dart:async';

void main() {
  runApp(const AllInOneApp());
}

class AllInOneApp extends StatelessWidget {
  const AllInOneApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'All In One Tool',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0F0F0F),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0F0F0F),
          elevation: 0,
          scrolledUnderElevation: 0,
          iconTheme: IconThemeData(color: Colors.white),
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.layers, size: 70, color: Colors.white),
            const SizedBox(height: 20),
            const Text(
              "ALL IN ONE",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, letterSpacing: 2, color: Colors.white),
            ),
            const SizedBox(height: 8),
            Text(
              "Premium Tools. 100% Free.",
              style: TextStyle(color: Colors.grey[400], fontSize: 14),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(bottom: 30.0),
        child: Text(
          "from Ayush Kumar",
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.grey[600], fontSize: 12, fontWeight: FontWeight.w500),
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> tools = [
      {"name": "Image to PDF", "icon": Icons.picture_as_pdf, "color": Colors.redAccent},
      {"name": "PDF to Image", "icon": Icons.image, "color": Colors.green},
      {"name": "Merge PDF", "icon": Icons.merge_type, "color": Colors.blueAccent},
      {"name": "Split PDF", "icon": Icons.call_split, "color": Colors.orange},
      {"name": "Compress PDF", "icon": Icons.compress, "color": Colors.purpleAccent},
      {"name": "Protect PDF", "icon": Icons.lock, "color": Colors.teal},
      {"name": "Unlock PDF", "icon": Icons.lock_open, "color": Colors.lightGreen},
      {"name": "Watermark PDF", "icon": Icons.branding_watermark, "color": Colors.cyan},
      {"name": "Sign PDF", "icon": Icons.draw, "color": Colors.amber},
      {"name": "Extract Text", "icon": Icons.text_snippet, "color": Colors.indigo},
      {"name": "Image Compressor", "icon": Icons.data_usage, "color": Colors.deepOrange},
      {"name": "Image Resizer", "icon": Icons.photo_size_select_large, "color": Colors.pinkAccent},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('All In One Tool', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 20)),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle_outlined, size: 28),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const CreatorScreen()),
              );
            },
          ),
          const SizedBox(width: 10),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              itemCount: (tools.length / 2).ceil(),
              itemBuilder: (context, index) {
                int first = index * 2;
                int second = first + 1;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12.0),
                  child: Row(
                    children: [
                      Expanded(child: _buildToolCard(context, tools[first])),
                      const SizedBox(width: 12),
                      Expanded(
                        child: second < tools.length 
                            ? _buildToolCard(context, tools[second]) 
                            : const SizedBox(),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Made in India ", style: TextStyle(color: Colors.grey[500], fontSize: 13)),
                const Icon(Icons.favorite, color: Colors.grey, size: 14),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildToolCard(BuildContext context, Map<String, dynamic> tool) {
    return InkWell(
      onTap: () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: const Color(0xFF333333),
            content: Text('${tool["name"]} is ready!', style: const TextStyle(color: Colors.white)),
            behavior: SnackBarBehavior.floating,
          ),
        );
      },
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF212121),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(tool["icon"], size: 36, color: tool["color"]),
            const SizedBox(height: 12),
            Text(
              tool["name"],
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.white),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

class CreatorScreen extends StatelessWidget {
  const CreatorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('About Creator', style: TextStyle(fontSize: 18)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const CircleAvatar(
              radius: 45,
              backgroundColor: Color(0xFF212121),
              child: Icon(Icons.person, size: 50, color: Colors.white),
            ),
            const SizedBox(height: 16),
            const Text(
              "Ayush Kumar",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 4),
            Text(
              "IIEST SHIBPUR Student",
              style: TextStyle(fontSize: 14, color: Colors.grey[400]),
            ),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF212121),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                "नमस्ते! मैं आयुष कुमार हूँ, IIEST Shibpur का स्टूडेंट।\\n\\nयह ऐप मैंने आप सभी के मजे और सारे प्रीमियम फीचर्स को 100% फ्री में इस्तेमाल करने के लिए बनाया है। बिना किसी ऐड्स या झंझट के! Hope you like it!",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 15, color: Colors.white, height: 1.5),
              ),
            ),
            const SizedBox(height: 30),
            const Text(
              "Support My Work",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 8),
            Text(
              "यह ऐप पूरी तरह से फ्री और मजे के लिए है। अगर आप सपोर्ट करना चाहें, तो Google Pay / UPI से गिफ्ट कर सकते हैं।",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: Colors.grey[400]),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Image.asset(
                'assets/qr_code.png',
                width: 180,
                height: 180,
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    width: 180,
                    height: 180,
                    color: Colors.grey[200],
                    child: const Center(
                      child: Text("QR Image Placeholder", textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "UPI ID: ayushku92sk@okicici",
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
"""

with open("pubspec.yaml", "w", encoding="utf-8") as f:
    f.write(pubspec_content)

with open("lib/main.dart", "w", encoding="utf-8") as f:
    f.write(main_dart_content)

with zipfile.ZipFile("AllInOneTool_CleanUI.zip", "w") as zipf:
    zipf.write("pubspec.yaml")
    zipf.write("lib/main.dart")
    if os.path.exists("assets/qr_code.png"):
        zipf.write("assets/qr_code.png")

print("AllInOneTool_CleanUI.zip successfully created!")